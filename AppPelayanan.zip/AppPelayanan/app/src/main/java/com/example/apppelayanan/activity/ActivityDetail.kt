package com.example.apppelayanan.activity

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.apppelayanan.databinding.ActivityDetailBinding
import com.example.apppelayanan.model.ResponTanggapan
import com.example.apppelayanan.retrofit.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ActivityDetail : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private var id_pengaduan: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        id_pengaduan = intent.getIntExtra("id_pengaduan", 999)
        Toast.makeText(this, "" + id_pengaduan, Toast.LENGTH_SHORT).show()

        binding.IvBack.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))
        }

        ApiClient.apiService.getTanggapanByIdPengaduan(id_pengaduan)
            .enqueue(object : Callback<ResponTanggapan>{
                override fun onResponse(
                    call: Call<ResponTanggapan>,
                    response: Response<ResponTanggapan>
                ) {
                    if (response.isSuccessful){
                        val data = response.body()
                        Log.d("mmk",""+data)
                        if (data != null){
                            val content = data.data[0]
                            binding.tvJenis.text = "${content.jenis}"
                            binding.TvPengaduan.text = "${content.pengaduan}"
                            binding.TvTglP.text = "${content.tglPengaduan}"
                            binding.TvTanggapan.text = "${content.tanggapan}"
                            binding.TvTglT.text = "${content.tglTanggapan}"
                        }
                    }
                }

                override fun onFailure(call: Call<ResponTanggapan>, t: Throwable) {
                    Log.d("error", ""+t.stackTraceToString())
                }

            })

    }
}