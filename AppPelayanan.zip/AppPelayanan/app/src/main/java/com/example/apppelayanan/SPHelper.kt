package com.example.apppelayanan

import android.content.Context
import android.content.SharedPreferences

class SPHelper(context: Context) {
    val login = "Login"
    val myPref = "Main_Pref"
    val sharedPreferences : SharedPreferences

    init {
        sharedPreferences = context .getSharedPreferences(myPref, Context.MODE_PRIVATE)
    }

    fun getStatusLogin() : Boolean{
        return sharedPreferences.getBoolean(login, false)
    }

    fun getNama(): String?{
        return sharedPreferences.getString("nama", "")
    }

    fun getJurusan(): String?{
        return sharedPreferences.getString("jurusan", "")
    }

    fun getKelas(): String?{
        return sharedPreferences.getString("kelas", "")
    }

    fun getNisn(): String?{
        return sharedPreferences.getString("nisn", "")
    }

    fun getIdSiswa(): String?{
        return sharedPreferences.getString("id_siswa", "")
    }

    fun setIdSiswa(id_siswa: String){
        sharedPreferences.edit().putString("id_siswa", id_siswa).apply()
    }

    fun setNama(nama: String){
        sharedPreferences.edit().putString("nama", nama).apply()
    }

    fun setNisn(nisn: String){
        sharedPreferences.edit().putString("nisn", nisn).apply()
    }

    fun setJurusan(jurusan: String){
        sharedPreferences.edit().putString("jurusan", jurusan).apply()
    }

    fun setKelas(kelas: String){
        sharedPreferences.edit().putString("kelas", kelas).apply()
    }

    fun setStatusLogin(status: Boolean){
        sharedPreferences.edit().putBoolean(login, status).apply()
    }
}