package com.example.apppelayanan.fragment

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.example.apppelayanan.RealPathUtils
import com.example.apppelayanan.SPHelper
import com.example.apppelayanan.activity.MainActivity
import com.example.apppelayanan.databinding.FragmentFormBinding
import com.example.apppelayanan.model.ResponPengaduan
import com.example.apppelayanan.retrofit.ApiClient
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.text.SimpleDateFormat
import java.util.*


class FormFragment : Fragment() {
    private lateinit var binding: FragmentFormBinding

    private lateinit var sp: SPHelper

    private lateinit var mUri: Uri
    private lateinit var mPath: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFormBinding.inflate(layoutInflater)

        sp = SPHelper(requireActivity())

        binding.btnpengaduan.setOnClickListener{
            if(mUri != null){
                addData(mUri)
            }else{
                Toast.makeText(requireActivity(), "Memek", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
        }

        binding.btnTake.isEnabled = true

        if (ActivityCompat.checkSelfPermission(
                requireActivity(),
                android.Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ){
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(android.Manifest.permission.CAMERA), 100)
        }else{
            binding.btnTake.isEnabled = true
        }

        binding.btnTake.setOnClickListener{
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
//            mUri = Uri.fromFile(getOutputMediaFile())
            val fileOutput = getOutputMediaFile()
            val fileName = fileOutput!!.name
            mUri = FileProvider.getUriForFile(requireActivity().applicationContext, requireActivity().applicationContext.packageName + ".provider", fileOutput!!)
            i.putExtra(MediaStore.EXTRA_OUTPUT, mUri)
            startActivityForResult(i, 101)
        }

        return binding.root

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101){
            if(mUri.path != null){
                val file = File(mUri.path)
                val fileName = file.name
                val path = requireActivity().getExternalFilesDir("bukti")!!.path
                val fileBukti = File(path + "/" + fileName)
                if(!fileBukti.exists()){
                    Toast.makeText(requireActivity(), "Image Not Found!", Toast.LENGTH_SHORT).show()
                }else{
                    binding.ivBukti.setImageURI(mUri)
                }
            }
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            binding.btnTake.isEnabled = true
        }
    }

    fun getOutputMediaFile(): File?{

        val path = requireActivity().getExternalFilesDir("bukti")!!.path
        val mediaStorageDir = File(path)
        if (!mediaStorageDir.exists()){
            if (!mediaStorageDir.mkdirs()){
                return null;
            }
        }
        val timeStamp = SimpleDateFormat("yyyyMMdd_kkmmss").format(Date());

        return File(mediaStorageDir.path + File.separator +
                timeStamp + "-"+ sp.getNisn() + ".jpeg");
    }

    private fun addData(contentUri: Uri){
        val SpJenis = binding.spJenis.selectedItem.toString()
        val IsiP = binding.etPengaduan.text.toString()
        val path = RealPathUtils.getRealPath(requireActivity(), contentUri)
        val Bukti = File(path)
        val MEDIA_TYPE_IMAGE: MediaType = "image/*".toMediaTypeOrNull()!!
        val fileBody: RequestBody = RequestBody.create(MEDIA_TYPE_IMAGE, Bukti)

        val body = MultipartBody.Part.createFormData("bukti", Bukti.name, fileBody)

        val idsiswa = sp.getIdSiswa().toString()
        val status = 0

        if (IsiP.isEmpty()) {
            binding.etPengaduan.error = "Isi Pengaduan Tidak Boleh Kososng"
            return
        }



        val reqIsip = RequestBody.create(okhttp3.MultipartBody.FORM, IsiP)
        val reqJenis = RequestBody.create(okhttp3.MultipartBody.FORM, SpJenis)
        val reqIdSiswa = RequestBody.create(okhttp3.MultipartBody.FORM, idsiswa)
        val reqStatus = RequestBody.create(okhttp3.MultipartBody.FORM, status.toString())

        Log.d("Imam", "" + idsiswa)
        ApiClient.apiService.addPengaduan(reqIsip, reqJenis, body, reqIdSiswa, reqStatus )
            .enqueue(object : Callback<ResponPengaduan>{
                override fun onResponse(
                    call: Call<ResponPengaduan>,
                    response: Response<ResponPengaduan>
                ) {
                    val response = response.body()
                    if (response != null){
                        if (response.status == false){
                            Toast.makeText(requireActivity(), "Pengaduan Gagal", Toast.LENGTH_SHORT).show()
                        }else{
                            Toast.makeText(requireActivity(), "Pengaduan Berhasil", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(requireActivity(), MainActivity::class.java))
                        }
                    }
                }

                override fun onFailure(call: Call<ResponPengaduan>, t: Throwable) {
                    Toast.makeText(requireActivity(), "Gagal", Toast.LENGTH_SHORT).show()
                    Log.d("gagal", "" + t.stackTraceToString())
                }

            })
    }





}