package com.example.apppelayanan.model


import com.google.gson.annotations.SerializedName

data class ResponKrisan(
    @SerializedName("data")
    val `data`: List<DataKrisan>,
    @SerializedName("status")
    val status: Boolean
)