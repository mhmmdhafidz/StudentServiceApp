package com.example.apppelayanan.model


import com.google.gson.annotations.SerializedName

data class DataTanggapan(
    @SerializedName("admin_id")
    val adminId: String,
    @SerializedName("email")
    val email: String,
    @SerializedName("id_admin")
    val idAdmin: String,
    @SerializedName("id_pengaduan")
    val idPengaduan: String,
    @SerializedName("id_tanggapan")
    val idTanggapan: String,
    @SerializedName("jenis")
    val jenis: String,
    @SerializedName("lvl_id")
    val lvlId: String,
    @SerializedName("nama_admin")
    val namaAdmin: String,
    @SerializedName("pass")
    val pass: String,
    @SerializedName("pengaduan")
    val pengaduan: String,
    @SerializedName("pengaduan_id")
    val pengaduanId: Int,
    @SerializedName("siswa_id")
    val siswaId: Int,
    @SerializedName("tanggapan")
    val tanggapan: String,
    @SerializedName("tanggapan_id")
    val tanggapanId: Any,
    @SerializedName("tgl_pengaduan")
    val tglPengaduan: String,
    @SerializedName("tgl_tanggapan")
    val tglTanggapan: String
)