package com.example.apppelayanan.model


import com.google.gson.annotations.SerializedName

data class ResponLogin(
    @SerializedName("message")
    val message: String,
    @SerializedName("nisn")
    val nisn: List<DataNisn>,
    @SerializedName("status")
    val status: Boolean
)