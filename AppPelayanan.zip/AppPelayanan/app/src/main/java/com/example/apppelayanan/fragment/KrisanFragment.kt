package com.example.apppelayanan.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.apppelayanan.SPHelper
import com.example.apppelayanan.activity.MainActivity
import com.example.apppelayanan.databinding.FragmentKrisanBinding
import com.example.apppelayanan.model.ResponKrisan
import com.example.apppelayanan.retrofit.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class KrisanFragment : Fragment() {
    private lateinit var binding: FragmentKrisanBinding

    private lateinit var sp: SPHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentKrisanBinding.inflate(layoutInflater)

        sp = SPHelper(requireActivity())

        binding.btnKrisan.setOnClickListener{
            addDataKrisan()
        }
        return binding.root

    }

    private fun addDataKrisan(){
        val IsiK = binding.etKrisan.text.toString()
        val idsiswa = sp.getIdSiswa().toString().toInt()

        if (IsiK.isEmpty()) {
            binding.etKrisan.error = "Isi Pengaduan Tidak Boleh Kososng"
            return
        }

        Log.d("AASDADAD", "" + idsiswa)
        ApiClient.apiService.addKrisan(IsiK, idsiswa)
            .enqueue(object : Callback<ResponKrisan>{
                override fun onResponse(
                    call: Call<ResponKrisan>,
                    response: Response<ResponKrisan>
                ) {
                    val response = response.body()
                    if (response != null){
                        if (response.status == false){
                            Toast.makeText(requireActivity(), "Pengaduan Gagal", Toast.LENGTH_SHORT).show()
                        }else{
                            Toast.makeText(requireActivity(), "Pengaduan Berhasil", Toast.LENGTH_SHORT).show()
                            startActivity(Intent(requireActivity(), MainActivity::class.java))
                        }
                    }
                }

                override fun onFailure(call: Call<ResponKrisan>, t: Throwable) {
                    Toast.makeText(requireActivity(), "Gagal", Toast.LENGTH_SHORT).show()
                    Log.d("gagal", "" + t.stackTraceToString())
                }

            })
    }
}