package com.example.apppelayanan.retrofit

import com.example.apppelayanan.model.ResponKrisan
import com.example.apppelayanan.model.ResponLogin
import com.example.apppelayanan.model.ResponPengaduan
import com.example.apppelayanan.model.ResponTanggapan
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*
import java.util.*

interface ApiService {


    @GET("Pengaduan")
    fun getPengaduanByIdSiswa(@Query("siswa_id") id_siswa: String ):Call<ResponPengaduan>

    @GET("Krisan")
    fun getKrisanByIdSiswa(@Query("siswa_id") id_siswa: String ):Call<ResponKrisan>

    @GET("Tanggapan")
    fun getTanggapanByIdPengaduan(@Query("pengaduan_id") id_pengaduan: Int ):Call<ResponTanggapan>

    @Multipart
    @POST("Pengaduan")
    fun addPengaduan(
        @Part("pengaduan") pengaduan: RequestBody,
        @Part("jenis") jenis: RequestBody,
        @Part file: MultipartBody.Part,
        @Part("siswa_id") siswa_id: RequestBody,
        @Part("status") status: RequestBody,
    ):Call<ResponPengaduan>

    @FormUrlEncoded
    @POST("Krisan")
    fun addKrisan(
        @Field("isi_krisan") isi: String,
        @Field("siswa_id") siswa_id: Int,
    ):Call<ResponKrisan>

    @FormUrlEncoded
    @POST("Login")
    fun addLogin(
        @Field("nisn") nisn:String,
        @Field("pass") pass:String
    ):Call<ResponLogin>
}