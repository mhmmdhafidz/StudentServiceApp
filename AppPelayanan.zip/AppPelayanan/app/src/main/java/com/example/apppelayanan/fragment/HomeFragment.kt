package com.example.apppelayanan.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.apppelayanan.SPHelper
import com.example.apppelayanan.adapter.PengaduanAdapter
import com.example.apppelayanan.databinding.FragmentHomeBinding
import com.example.apppelayanan.model.DataPengaduan
import com.example.apppelayanan.model.ResponPengaduan
import com.example.apppelayanan.retrofit.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding
    private lateinit var pengaduanAdapter: PengaduanAdapter
    private lateinit var sp: SPHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentHomeBinding.inflate(layoutInflater)
        sp = SPHelper(requireActivity())

        pengaduanAdapter = PengaduanAdapter(requireActivity(), arrayListOf())

        binding.rvHome.adapter = pengaduanAdapter
        binding.rvHome.setHasFixedSize(true)
        binding.rvHome.layoutManager = LinearLayoutManager(requireActivity())

        remoteGetPengaduan()

        // Inflate the layout for this fragment
        return binding.root
    }

    fun remoteGetPengaduan(){
        Log.d("AASDADAD", "" + sp.getIdSiswa())
        ApiClient.apiService.getPengaduanByIdSiswa(sp.getIdSiswa()!!).enqueue(object : Callback<ResponPengaduan>{
            override fun onResponse(
                call: Call<ResponPengaduan>,
                response: Response<ResponPengaduan>
            ) {
                if(response.isSuccessful){
                    val data = response.body()
                    Log.d("Cekkkdadata", "" + data?.data)
                    setDataToAdapter(data!!.data)
                }
            }

            override fun onFailure(call: Call<ResponPengaduan>, t: Throwable) {
                Log.d("Error", "" + t.stackTraceToString())
            }
        })
    }

    fun setDataToAdapter(data : ArrayList<DataPengaduan>){
        pengaduanAdapter.setData(data)
    }

}