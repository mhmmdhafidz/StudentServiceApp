package com.example.apppelayanan.model


import com.google.gson.annotations.SerializedName

data class ResponTanggapan(
    @SerializedName("data")
    val `data`: List<DataTanggapan>,
    @SerializedName("status")
    val status: Boolean
)