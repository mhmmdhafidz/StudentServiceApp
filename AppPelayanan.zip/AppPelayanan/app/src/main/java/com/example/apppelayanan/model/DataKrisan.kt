package com.example.apppelayanan.model


import com.google.gson.annotations.SerializedName

data class DataKrisan(
    @SerializedName("id_krisan")
    val idKrisan: String,
    @SerializedName("id_siswa")
    val idSiswa: String,
    @SerializedName("isi_krisan")
    val isiKrisan: String
)