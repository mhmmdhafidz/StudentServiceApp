package com.example.apppelayanan

import android.annotation.SuppressLint
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.loader.content.CursorLoader
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream

class RealPathUtils {

    companion object{

        fun getRealPath(context: Context?, fileUri: Uri?): String? {
            val realPath: String
            // SDK < API11
            realPath = if (Build.VERSION.SDK_INT < 11) {
                RealPathUtils.getRealPathFromURI_BelowAPI11(context!!, fileUri)!!
            } else if (Build.VERSION.SDK_INT < 19) {
                RealPathUtils.getRealPathFromURI_API11to18(context, fileUri)!!
            } else {
                RealPathUtils.getRealPathFromURI_API19(context!!, fileUri)!!
            }
            return realPath
        }

        @SuppressLint("NewApi")
        fun getRealPathFromURI_API19(context: Context, uri: Uri?): String? {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val cursor = uri?.let {
                    context.contentResolver.query(
                        it,
                        arrayOf<String>(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                        null,
                        null
                    )
                }
                cursor!!.moveToFirst()
                val displayName =
                    cursor.getString(cursor.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
                val size = cursor.getLong(cursor.getColumnIndexOrThrow(OpenableColumns.SIZE))
                val file = File("" + context.filesDir + "/" + displayName)
                try {
                    val fileOutputStream = FileOutputStream(file)
                    val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                    val buffers = ByteArray(1024)
                    var read: Int
                    while (inputStream!!.read(buffers).also { read = it } != -1) {
                        fileOutputStream.write(buffers, 0, read)
                    }
                    inputStream.close()
                    fileOutputStream.close()
                    return file.getPath()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
            var filePath = ""
            val wholeID = DocumentsContract.getDocumentId(uri)

            // Split at colon, use second item in the array
            val id = wholeID.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()[1]
            val column = arrayOf(MediaStore.Images.Media.DATA)

            // where id is equal to
            val sel = MediaStore.Images.Media._ID + "=?"
            val cursor: Cursor? = context.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                column, sel, arrayOf(id), null
            )
            val columnIndex: Int? = cursor?.getColumnIndex(column[0])
            if (cursor!!.moveToFirst()) {
                filePath = cursor.getString(columnIndex!!)
            }
            cursor.close()
            return filePath
        }


        @SuppressLint("NewApi")
        fun getRealPathFromURI_API11to18(context: Context?, contentUri: Uri?): String? {
            val proj = arrayOf(MediaStore.Images.Media.DATA)
            var result: String? = null
            val cursorLoader = CursorLoader(
                context!!,
                contentUri!!, proj, null, null, null
            )
            val cursor: Cursor? = cursorLoader.loadInBackground()
            if (cursor != null) {
                val column_index: Int = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                cursor.moveToFirst()
                result = cursor.getString(column_index)
            }
            return result
        }

        fun getRealPathFromURI_BelowAPI11(context: Context, contentUri: Uri?): String? {
            val proj = arrayOf(MediaStore.Images.Media.DATA)
            val cursor: Cursor? =
                context.getContentResolver().query(contentUri!!, proj, null, null, null)
            val column_index: Int = cursor?.getColumnIndexOrThrow(MediaStore.Images.Media.DATA) ?: 0
            cursor?.moveToFirst()
            return cursor?.getString(column_index)
        }
    }

}