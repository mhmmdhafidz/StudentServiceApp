package com.example.apppelayanan.model


import com.google.gson.annotations.SerializedName

data class ResponPengaduan(
    @SerializedName("data")
    val `data`: ArrayList<DataPengaduan>,
    @SerializedName("status")
    val status: Boolean
)