package com.example.apppelayanan.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.apppelayanan.R
import com.example.apppelayanan.SPHelper
import com.example.apppelayanan.model.ResponLogin
import com.example.apppelayanan.retrofit.ApiClient
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {
    lateinit var sp : com.example.apppelayanan.SPHelper
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sp = SPHelper(this)
        btnLogin.setOnClickListener{
            login()
        }
    }
    private fun login(){
        val nisn = etNisn.text.toString()
        val pass = etPass.text.toString()

        if (nisn.isEmpty() && pass.isEmpty()){
            Toast.makeText(this, "Password dan Nisn Harus diisi", Toast.LENGTH_SHORT).show()
            etNisn.error = "Nisn Tidak Boleh Kosong"
            etPass.error = "Password Tidak Boleh Kosong"
            return
        }
        if (nisn.isEmpty()){
            etNisn.error = "Nisn Tidak Boleh Kososng"
            return
        }
        if (pass.isEmpty()){
            etPass.error = "Password Tidak Boleh Kosong"
            return
        }
        ApiClient.apiService.addLogin(nisn, pass)
            .enqueue(object : Callback<ResponLogin>{
                override fun onResponse(call: Call<ResponLogin>, response: Response<ResponLogin>) {
                    val response = response.body()

                    if (response != null){
                        if (response.status == false){
                            Toast.makeText(this@LoginActivity, response.message, Toast.LENGTH_SHORT).show()
                        }else{
                            val dt = response.nisn.get(0)
                            sp.setStatusLogin(true)
                            sp.setIdSiswa(dt.idSiswa)
                            sp.setNama(dt.nama)
                            sp.setNisn(dt.nisn)
                            sp.setJurusan(dt.jurusan)
                            sp.setKelas(dt.kelas)

                            startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                        }
                    }
                }

                override fun onFailure(call: Call<ResponLogin>, t: Throwable) {
                    Toast.makeText(this@LoginActivity, t.localizedMessage, Toast.LENGTH_LONG).show()
                }

            })
    }
}