package com.example.apppelayanan.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.apppelayanan.R
import com.example.apppelayanan.fragment.FormFragment
import com.example.apppelayanan.fragment.HomeFragment
import com.example.apppelayanan.fragment.KrisanFragment
import com.example.apppelayanan.fragment.ProfilFragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fragment = HomeFragment()
        view.setOnNavigationItemSelectedListener(menuItemSelected)
        addFragment(fragment)

    }



    private val menuItemSelected = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.itemHome ->{
                val fragment = HomeFragment()
                addFragment(fragment)
                return@OnNavigationItemSelectedListener true
            }
            R.id.itemForm ->{
                val fragment = FormFragment()
                addFragment(fragment)
                return@OnNavigationItemSelectedListener true
            }
            R.id.itemKrisan ->{
                val fragment = KrisanFragment()
                addFragment(fragment)
                return@OnNavigationItemSelectedListener true
            }
            R.id.itemProfil ->{
                val fragment = ProfilFragment()
                addFragment(fragment)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    private fun addFragment(fragment: Fragment){
        supportFragmentManager
            .beginTransaction()
            .setCustomAnimations(com.google.android.material.R.anim.design_bottom_sheet_slide_in, com.google.android.material.R.anim.design_bottom_sheet_slide_out )
            .replace(R.id.content, fragment, fragment.javaClass.getSimpleName())
            .commit()
    }
}