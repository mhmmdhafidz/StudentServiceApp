package com.example.apppelayanan.model


import com.google.gson.annotations.SerializedName

data class DataNisn(
    @SerializedName("id_siswa")
    val idSiswa: String,
    @SerializedName("jurusan")
    val jurusan: String,
    @SerializedName("kelas")
    val kelas: String,
    @SerializedName("lvl_id")
    val lvlId: String,
    @SerializedName("nama")
    val nama: String,
    @SerializedName("nisn")
    val nisn: String,
    @SerializedName("pass")
    val pass: String
)