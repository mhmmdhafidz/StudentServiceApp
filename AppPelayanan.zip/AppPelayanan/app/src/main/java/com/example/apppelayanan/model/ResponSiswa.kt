package com.example.apppelayanan.model


import com.google.gson.annotations.SerializedName

data class ResponSiswa(
    @SerializedName("data")
    val `data`: List<DataSiswa>,
    @SerializedName("status")
    val status: Boolean
)