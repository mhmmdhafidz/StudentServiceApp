package com.example.apppelayanan.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity
import com.example.apppelayanan.R
import com.example.apppelayanan.SPHelper

class SplashScreen : AppCompatActivity() {
    private lateinit var sp: SPHelper
    private val TAG: String = "SplashScreen"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        sp = SPHelper(this)
        Handler().postDelayed({
            if (sp.getStatusLogin() == true){
                startActivity(Intent(this, MainActivity::class.java))
            }else{
                startActivity(Intent(this, LoginActivity::class.java))
            }
        },2000)
    }
}