package com.example.apppelayanan.model


import com.google.gson.annotations.SerializedName

data class DataPengaduan(

    @SerializedName("id_pengaduan")
    val idPengaduan: Int,
    @SerializedName("jenis")
    val jenis: String,
    @SerializedName("pengaduan")
    val Pengaduan: String,
    @SerializedName("bukti")
    val Bukti: String,
    @SerializedName("siswa_id")
    val siswaId: Int,
    @SerializedName("tgl_pengaduan")
    val tglPengaduan: String,
    @SerializedName("status")
    val status: Int,

)