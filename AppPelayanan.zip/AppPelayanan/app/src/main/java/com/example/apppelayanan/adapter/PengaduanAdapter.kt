package com.example.apppelayanan.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.apppelayanan.R
import com.example.apppelayanan.activity.ActivityDetail
import com.example.apppelayanan.model.DataPengaduan
import com.google.android.material.imageview.ShapeableImageView

class PengaduanAdapter(
    private val context: Context,
    private val dataPengaduanList: ArrayList<DataPengaduan>
    ): RecyclerView.Adapter<PengaduanAdapter.MyViewHolder>() {

    class MyViewHolder(val view: View):RecyclerView.ViewHolder (view) {
        val tvJenisP = view.findViewById<TextView>(R.id.tv_jenisp)
        val tvTglP = view.findViewById<TextView>(R.id.tv_tglp)
        val sivDetailP = view.findViewById<ShapeableImageView>(R.id.siv_detailp)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val itemView = layoutInflater.inflate(R.layout.card_home, parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.tvJenisP.text = dataPengaduanList.get(position).jenis
        holder.tvTglP.text = dataPengaduanList.get(position).tglPengaduan
        holder.sivDetailP.setOnClickListener{
            if(dataPengaduanList.get(position).status == 0){
                Toast.makeText(context, "Pengaduan Belum Ditanggapi", Toast.LENGTH_SHORT).show()
            }else{
                val i = Intent(context, ActivityDetail::class.java)
                i.putExtra("id_pengaduan", dataPengaduanList.get(position).idPengaduan)
                context.startActivity(i)
            }
        }
    }

    override fun getItemCount(): Int = dataPengaduanList.size

    fun setData(data : ArrayList<DataPengaduan>){
        dataPengaduanList.clear()
        dataPengaduanList.addAll(data)
        notifyDataSetChanged()
    }
}